<h1>Daftar Matakuliah</h1>
<table border="1" width="100%">
    <thead>
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Nama Matakuliah</th>
            <th>Jumlah SKS</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $nomor = 1;
    foreach($list_matkul as $obj){
        ?>
        <tr>
            <td><?=$nomor?></td>
            <td><?=$obj->kode?></td>
            <td><?=$obj->nama?></td>
            <td><?=$obj->sks?></td>
    <?php
    $nomor++;
    }?>
    </tbody>
</table>